from django.urls import path
from .views import FrameListCreateAPIView,FrameDetailAPIView , PredictionDetailAPIView , PredictionListCreateAPIView, DetectionDetailAPIView, DetectionListCreateAPIView,DashboardDataAPIView,NotificationData

urlpatterns = [
    #Frame API 
    path('frame/',FrameListCreateAPIView.as_view(),name='frame-list-create'), #list all frames(GET) and create a new frame(POST)
    path('frame/<int:pk>/',FrameDetailAPIView.as_view(),name='frame-detail'), #retrieve(GET), update(PUT), or delete(DELETE) a specific frame using its primary key (pk)

    # Prediction API endpoints
    path('predictions/', PredictionListCreateAPIView.as_view(), name='prediction-list-create'),# list all predictions(GET) and create a new prediction(POST)
    path('predictions/<int:pk>/', PredictionDetailAPIView.as_view(), name='prediction-detail'),# retrieve(GET), update(PUT), or delete(DELETE) a specific prediction using its primary key (pk)

    # detection API endpoints
    path('detections/', DetectionListCreateAPIView.as_view(), name='detection-list-create'), 
    path('detections/<int:pk>/', DetectionDetailAPIView.as_view(), name='detection-detail'),
    path('line-chart/', DashboardDataAPIView.as_view(), name='chart_data'),
    path('Notification/',NotificationData.as_view(), name='NotificationData'),



]
