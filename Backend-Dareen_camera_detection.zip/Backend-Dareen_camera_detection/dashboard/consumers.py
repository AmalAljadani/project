
# consumer.py

import json
from channels.generic.websocket import AsyncWebsocketConsumer

class DashboardConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print(f"WebSocket dashboard connected: {self.channel_name}")
        await self.accept()
        await self.channel_layer.group_add('dashboard_updates', self.channel_name)

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard('dashboard_updates', self.channel_name)

    async def receive(self, text_data):
        pass  # not used

    async def send_update(self, event):
        # event = { 'type': 'send_update', 'data': { ... } }
        # unwrap it so the client sees { 'type', 'timestamp', 'crowd_density', 'camera_id', … }
        print("📡 [consumer] got event:", event)
        await self.send(text_data=json.dumps(event['data']))
