from django.db import models
from camera_control.models import Camera
from user.models import User
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

class Frame(models.Model):
    id = models.AutoField(primary_key=True)
   
    timestamp = models.DateTimeField(auto_now_add=True)
    frame= models.ImageField(upload_to='frames/') 
    camera = models.ForeignKey(Camera, on_delete=models.CASCADE, related_name="frames")

    def __str__(self):
        return f"Frame {self.id} at Camera {self.camera.id} at {self.timestamp}"

class Detection(models.Model):
    id = models.AutoField(primary_key=True)
    crowd_density = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now_add=True, null=True)

    frame = models.ForeignKey(
        Frame, on_delete=models.CASCADE, related_name="frame_count"
    )

    def __str__(self):
        return f"Detection {self.id} Frame {self.frame.id} with {self.crowd_density}"

class Prediction(models.Model):
    id = models.AutoField(primary_key=True)
    overcrowd_validity = models.BooleanField(default=False)
    crowd_density = models.IntegerField(default=0) 
    timestamp = models.DateTimeField(auto_now_add=True)

    frame = models.ForeignKey(
        Frame, on_delete=models.CASCADE, related_name="frame_pred", null=True
    )

    def __str__(self):
        return f"Prediction {self.id}  Frame {self.frame.id} {self.timestamp}"

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    source = models.CharField(max_length=20)  # 'prediction' or 'detection'
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.message


