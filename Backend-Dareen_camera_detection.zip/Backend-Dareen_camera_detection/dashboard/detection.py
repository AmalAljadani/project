# #detection.py
# from asgiref.sync      import async_to_sync
# from channels.layers   import get_channel_layer
# import os
# import sys
# import django

# #sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# #os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'my_project.settings')
# #django.setup()

# from dashboard.models import Detection, Frame
# from camera_control.models import Camera
# from ultralytics import YOLO
# import pandas as pd
# from dashboard.views import broadcast_new_data
# #import models
# detection_model = "dashboard/ai_models/yolov11.pt"
# yolo_model = YOLO(detection_model)  

# def process_frame_detection_task(frame_id):
#     try:
#         #retreive frame
#         frame_object = Frame.objects.get(id=frame_id)
#         print("✅ Signal working! Frame path:", frame_object.frame.path)
#         frame_path = frame_object.frame.path        

#         #get numbers of head from yolo results
#         results = yolo_model(frame_path)
#         boxes = results[0].boxes
#         df = pd.DataFrame(boxes.xywh.cpu().numpy(), columns=['xcenter', 'ycenter', 'width', 'height'])
#         df['class'] = boxes.cls.cpu().numpy()
#         crowd_density = (df['class'] == 0).sum()


#         #create detection object 
#         detection = Detection.objects.create(frame=frame_object, crowd_density=crowd_density)
#         detection.save()

#          # 1) Directly publish into Redis (optional; broadcast_new_data does this too)
#         layer = get_channel_layer()
#         print("🔍 [detection] using channel layer:", layer)
#         async_to_sync(layer.group_send)(
#             'dashboard_updates',
#             {
#                'type': 'send_update',
#                'data': {
#                    'type':          'detection',
#                    'timestamp':     detection.timestamp.isoformat(),
#                    'crowd_density': detection.crowd_density,
#                    'camera_id':     frame.camera.id,
#                }
#             }
#         )

#         # 2) Or just call your helper, which does the same
#         broadcast_new_data('detection', detection)




#     except Exception as e:
#         # Log the exception as needed; here we simply print it.
#         print("Error processing frame:", e)
#         # Optionally, raise the error or return error details.
#         return str(e)    


# detection.py
from asgiref.sync      import async_to_sync
from channels.layers   import get_channel_layer
from dashboard.models  import Detection, Frame
from dashboard.views   import broadcast_new_data
from ultralytics       import YOLO
import pandas as pd

# Load the model once
yolo_model = YOLO("dashboard/ai_models/yolov11.pt")

def process_frame_detection_task(frame_id):
    try:
        frame_obj = Frame.objects.get(id=frame_id)
        print("✅ Signal working! Frame path:", frame_obj.frame.path)

        # Run YOLO and count heads
        results = yolo_model(frame_obj.frame.path)
        boxes   = results[0].boxes
        df      = pd.DataFrame(
                     boxes.xywh.cpu().numpy(),
                     columns=['xcenter','ycenter','width','height']
                  )
        df['class']     = boxes.cls.cpu().numpy()
        crowd_density   = int((df['class'] == 0).sum())

        # Save the detection
        detection = Detection.objects.create(
            frame=frame_obj,
            crowd_density=crowd_density
        )

        # INLINE broadcast (optional—your helper does the same)
        layer = get_channel_layer()
        print("🔍 [detection] using channel layer:", layer)
        async_to_sync(layer.group_send)(
            'dashboard_updates',
            {
                'type': 'send_update',
                'data': {
                    'type':          'detection',
                    'timestamp':     detection.timestamp.isoformat(),
                    'crowd_density': detection.crowd_density,
                    'camera_id':     frame_obj.camera.id,      # <— use frame_obj, not frame
                }
            }
        )

        # OR simply call your helper:
        # broadcast_new_data('detection', detection)

    except Exception as e:
        print("Error processing frame:", e)
        return str(e)
