from datetime import datetime, timedelta
from django.shortcuts import get_object_or_404, render
from rest_framework.permissions import IsAuthenticated

from .serializers import FrameSerializer, PredictionSerializer, DetectionSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from .models import Frame, Prediction, Detection
from user.models import Location
from camera_control.models import Camera
# Create your views here.

# views.py
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

# def broadcast_new_data(data_type, instance):
#     """
#     Broadcast new data to all connected clients.
#     """
#     print(f"Broadcasting new {data_type}: {instance.timestamp}, {instance.crowd_density}")
#     channel_layer = get_channel_layer()
#     async_to_sync(channel_layer.group_send)(
#         'dashboard_updates',
#         {
#             'type': 'send_update',
#             'data': {
#                 'type': data_type,  # 'prediction' or 'detection'
#                 'timestamp': instance.timestamp.isoformat(),
#                 'crowd_density': instance.crowd_density,
#             }
#         }
#     )

def broadcast_new_data(data_type, instance):
    camera = instance.frame.camera
    channel_layer = get_channel_layer()
    print("Using channel layer:", channel_layer)
    print(f"📣 [broadcast_new_data] sending to dashboard_updates: {data_type=} {instance.id=}")

    async_to_sync(channel_layer.group_send)(
        'dashboard_updates',
        {
            'type': 'send_update',
            'data': {
                'type':          data_type,  
                'timestamp':     instance.timestamp.isoformat(),
                'crowd_density': instance.crowd_density,
                'camera_id':     camera.id,            # ← must include this
            }
        }
    )


class FrameListCreateAPIView(APIView):
    def get(self, request):
        """
        Retrieve all frames.
        """
        frames = Frame.objects.all()
        serializer = FrameSerializer(frames, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        """
        Create a new frame.
        """
        # # Ensure timestamp is set automatically if not provided
        # data = request.data.copy()
        # if "timestamp" not in data or not data["timestamp"]:
        #     data["timestamp"] = timezone.now()

        serializer = FrameSerializer(data=request.data)
        if serializer.is_valid():
           # instance = serializer.save()
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class FrameDetailAPIView(APIView):
    def get_object(self, pk):
        """
        Helper function to retrieve a Frame object by ID.
        """
        try:
            return Frame.objects.get(pk=pk)
        except Frame.DoesNotExist:
            return None

    def get(self, request, pk):
        """
        Retrieve a specific frame by ID.
        """
        frame = self.get_object(pk)
        if frame is None:
            return Response(
                {"error": "Frame not found"}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = FrameSerializer(frame)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk):
        """
        Update a frame's details.
        """
        frame = self.get_object(pk)
        if frame is None:
            return Response(
                {"error": "Frame not found"}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = FrameSerializer(
            frame, data=request.data, partial=True
        )  # Allows partial updates
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """
        Delete a frame by ID.
        """
        frame = self.get_object(pk)
        if frame is None:
            return Response(
                {"error": "Frame not found"}, status=status.HTTP_404_NOT_FOUND
            )

        frame.delete()
        return Response(
            {"message": "Frame deleted successfully"}, status=status.HTTP_204_NO_CONTENT
        )


class PredictionListCreateAPIView(APIView):
    def get(self, request):
        """
        Retrieve all predictions.
        """
        predictions = Prediction.objects.all()
        serializer = PredictionSerializer(predictions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        """
        Create a new prediction.
        """
        data = request.data.copy()
        if "timeStamp" not in data or not data["timeStamp"]:
            data["timeStamp"] = timezone.now()

        serializer = PredictionSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            # Broadcast the new prediction
            broadcast_new_data('prediction', serializer.instance)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PredictionDetailAPIView(APIView):
    def get_object(self, pk):
        """
        Helper function to retrieve a Prediction object by ID.
        """
        try:
            return Prediction.objects.get(pk=pk)
        except Prediction.DoesNotExist:
            return None

    def get(self, request, pk):
        """
        Retrieve a specific prediction by ID.
        """
        prediction = self.get_object(pk)
        if prediction is None:
            return Response(
                {"error": "Prediction not found"}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = PredictionSerializer(prediction)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk):
        """
        Update a prediction's details.
        """
        prediction = self.get_object(pk)
        if prediction is None:
            return Response(
                {"error": "Prediction not found"}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = PredictionSerializer(prediction, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """
        Delete a prediction by ID.
        """
        prediction = self.get_object(pk)
        if prediction is None:
            return Response(
                {"error": "Prediction not found"}, status=status.HTTP_404_NOT_FOUND
            )

        prediction.delete()
        return Response(
            {"message": "Prediction deleted successfully"},
            status=status.HTTP_204_NO_CONTENT,
        )


class DetectionDetailAPIView(APIView):
    def get(self, request):
        """
        Retrieve a list of all detections, with optional filtering by frame.
        """
        frame_id = request.GET.get('frame')  # Get frame ID from query parameters
        detections = Detection.objects.all()

        if frame_id:
            detections = detections.filter(frame__id=frame_id)  # Filter by frame ID

        serializer = DetectionSerializer(detections, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
     
    def put(self, request, pk):
        """
        Update a detection's details.
        """
        detection = self.get_object(pk)
        if detection is None:
            return Response(
                {"error": "Detection not found"}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = DetectionSerializer(
            detection, data=request.data, partial=True
        )  # Allows partial updates
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """
        Delete a detection by ID.
        """
        detection = self.get_object(pk)
        if detection is None:
            return Response(
                {"error": "Detection not found"}, status=status.HTTP_404_NOT_FOUND
            )

        detection.delete()
        return Response(
            {"message": "Detection deleted successfully"},
            status=status.HTTP_204_NO_CONTENT,
        )


class DetectionListCreateAPIView(APIView):
    def get(self, request):
        """
        Retrieve a list of all detections.
        """
        detections = Detection.objects.all()
        serializer = DetectionSerializer(detections, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        """
        Create a new detection entry.
        """
        serializer = DetectionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            # Broadcast the new detection
            broadcast_new_data('detection', serializer.instance)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




from django.utils import timezone
from datetime import datetime, timedelta
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Prediction, Detection
from django.db.models import Sum
from django.utils.timezone import make_aware

# class DashboardDataAPIView(APIView):
#     def get(self, request, *args, **kwargs):
#         """
#         Fetch Predections and Detection dashboard data without authentication.
#         filterd by date 
#         """

#         # Get the date parameter from the request
#         date_str = request.query_params.get('date')

#          # Check if the date parameter is provided
#         if not date_str:
#             return Response({'error': 'Date parameter is required'}, status=status.HTTP_400_BAD_REQUEST)
        
#         try:
#              # Parse the date string into a date object
#             requested_date = datetime.strptime(date_str, '%Y-%m-%d').date()
#         except ValueError:
#             return Response({'error': 'Invalid date format. Use YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)
        
#         # Calculate the start and end of the requested day
#         start_of_day = make_aware(datetime.combine(requested_date, datetime.min.time()))
#         end_of_day = start_of_day + timedelta(days=1)

#         # Filter predictions and detections for the requested date
#         predictions = Prediction.objects.filter(timestamp__gte=start_of_day, timestamp__lt=end_of_day)
#         detections = Detection.objects.filter(timestamp__gte=start_of_day, timestamp__lt=end_of_day)

#         # Serialize the data
#         prediction_serializer = PredictionSerializer(predictions, many=True)
#         detection_serializer = DetectionSerializer(detections, many=True)

#         if not predictions.exists() or not detections.exists():
#             return Response({
#                 'message': 'No records found for the requested date',
#                 'predictions': [],
#                 'detections': [],
#             })

#          # Return the serialized data in the response
#         return Response({
#             'predictions': prediction_serializer.data,
#             'detections': detection_serializer.data,
#         })

#----------------------------------00000000000000000======================================
# dashboard version working 18 april 2025

# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from rest_framework.permissions import IsAuthenticated
# from datetime import datetime, timedelta
# from django.utils.timezone import make_aware
# from .serializers import PredictionSerializer, DetectionSerializer,NotificationSerializer
# from user.serializers import LocationSerializer
# from camera_control.serializers import CameraSerializer

# class DashboardDataAPIView(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure the user is authenticated

#     def get(self, request, *args, **kwargs):
#         user = request.user
#         if user.is_anonymous:
#             return Response({'error': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)

#         # Get the date and camera_id parameters from the request
#         date_str = request.query_params.get('date')
#         camera_id = request.query_params.get('camera_id')

#         # Check if the date parameter is provided
#         if not date_str:
#             return Response({'error': 'Date parameter is required'}, status=status.HTTP_400_BAD_REQUEST)
        
#         try:
#             # Parse the date string into a date object
#             requested_date = datetime.strptime(date_str, '%Y-%m-%d').date()
#         except ValueError:
#             return Response({'error': 'Invalid date format. Use YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)
        
#         # Calculate the start and end of the requested day
#         start_of_day = make_aware(datetime.combine(requested_date, datetime.min.time()))
#         end_of_day = start_of_day + timedelta(days=1)

#         # Get the user's location
#         location = Location.objects.filter(user=user).first()
#         if not location:
#             return Response({'error': 'User location not found'}, status=status.HTTP_404_NOT_FOUND)

#         # Get the cameras for the user's location
#         cameras = Camera.objects.filter(location=location)
#         if not cameras.exists():
#             return Response({'error': 'No cameras found for the user location'}, status=status.HTTP_404_NOT_FOUND)

#         # If a specific camera is selected, filter by that camera
#         if camera_id:
#              camera = cameras.filter(id=camera_id).first()  # Get a single Camera instance
#              if not camera:
#                  return Response({'error': 'Camera not found'}, status=status.HTTP_404_NOT_FOUND)
#         else:
#              camera = cameras.first()  # Default to the first available camera


#         # Filter predictions and detections for the requested date and camera(s)
#         predictions = Prediction.objects.filter(timestamp__gte=start_of_day, timestamp__lt=end_of_day, frame__camera__in=cameras)
#         detections = Detection.objects.filter(timestamp__gte=start_of_day, timestamp__lt=end_of_day, frame__camera__in=cameras)

#         # Serialize the data
#         prediction_serializer = PredictionSerializer(predictions, many=True)
#         detection_serializer = DetectionSerializer(detections, many=True)
#         location_serializer = LocationSerializer(location)
#         #camera_serializer = CameraSerializer(cameras)

#         if not predictions.exists() and not detections.exists():
#             return Response({
#                 'message': 'No records found for the requested date and camera',
#                 'predictions': [],
#                 'detections': [],
#             })

#         # Return the serialized data in the response
#         return Response({
#             'predictions': prediction_serializer.data,
#             'detections': detection_serializer.data,
#             'locattion': location_serializer.data,
#             'camera human threshold': camera.human_threshold
#         })
    
from datetime import datetime, timedelta
from django.utils.timezone import make_aware, now
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated

from camera_control.models import Camera
from .models import Prediction, Detection
from .serializers import PredictionSerializer, DetectionSerializer

class DashboardDataAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous:
            return Response(
                {'error': 'Authentication required'},
                status=status.HTTP_401_UNAUTHORIZED
            )

        # ── 1) Parse & validate the date parameter ───────────────────────────────
        date_str = request.query_params.get('date')
        if not date_str:
            return Response(
                {'error': 'Date parameter is required (YYYY-MM-DD)'},
                status=status.HTTP_400_BAD_REQUEST
            )
        try:
            requested_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return Response(
                {'error': 'Invalid date format. Use YYYY-MM-DD'},
                status=status.HTTP_400_BAD_REQUEST
            )
        start_of_day = make_aware(datetime.combine(requested_date, datetime.min.time()))
        end_of_day   = start_of_day + timedelta(days=1)

        # ── 2) Resolve the user’s cameras & pick one ──────────────────────────────
        cameras = Camera.objects.filter(location__user=user)
        if not cameras.exists():
            return Response(
                {'error': 'No cameras found for your account'},
                status=status.HTTP_404_NOT_FOUND
            )
        camera_id = request.query_params.get('camera_id')
        if camera_id:
            camera = cameras.filter(id=camera_id).first()
            if not camera:
                return Response(
                    {'error': 'Camera not found'},
                    status=status.HTTP_404_NOT_FOUND
                )
        else:
            camera = cameras.first()

        # ── 3) Fetch only that camera’s records within the day, ordered by time ───
        preds = Prediction.objects.filter(
            timestamp__gte=start_of_day,
            timestamp__lt=end_of_day,
            frame__camera=camera
        ).order_by('timestamp')
        dets  = Detection.objects.filter(
            timestamp__gte=start_of_day,
            timestamp__lt=end_of_day,
            frame__camera=camera
        ).order_by('timestamp')

        # ── 4) Serialize them ─────────────────────────────────────────────────────
        pred_data = PredictionSerializer(preds, many=True).data
        det_data  = DetectionSerializer(dets, many=True).data

        # ── 5) Compute true chart bounds from these records (fallback to day slice)
        if pred_data or det_data:
            all_ts = [
                datetime.fromisoformat(r['timestamp'])
                for r in (pred_data + det_data)
            ]
            start_ts = min(all_ts)
            end_ts   = max(all_ts)
        else:
            start_ts = start_of_day
            end_ts   = end_of_day

        # ── 6) Build & send the response ─────────────────────────────────────────
        return Response({
            'predictions': pred_data,
            'detections':  det_data,
            'start_time':  start_ts.isoformat(),
            'end_time':    end_ts.isoformat(),
            'camera': {
                'id':              camera.id,
                'human_threshold': camera.human_threshold,
            }
        })



from django.db.models import F, Prefetch
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

# Assuming Camera is imported from camera_control.models
# and models Frame, Detection, and Prediction are defined as shown.

class NotificationData(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        print(f"Authenticated User: {user}")  # Debug log

        if user.is_anonymous:
            return Response({'error': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)

        # Log the Authorization header (debugging)
        print(f"Auth Header: {request.META.get('HTTP_AUTHORIZATION')}")

        # Filter cameras for which the camera's associated location belongs to the user.
        # Then prefetch related frames, and for each frame, prefetch predictions and detections
        # that have crowd_density >= camera.human_threshold.
        cameras = (
            Camera.objects.filter(location__user=user)
            .prefetch_related(
                Prefetch(
                    'frames',  # Reverse relation from Camera to Frame (as defined by related_name="frames")
                    queryset=Frame.objects.prefetch_related(
                        Prefetch(
                            'frame_pred',  # Reverse relation for Prediction objects (related_name="frame_pred")
                            queryset=Prediction.objects.filter(
                                crowd_density__gte=F('frame__camera__human_threshold')
                            ),
                            to_attr='filtered_predictions'
                        ),
                        Prefetch(
                            'frame_count',  # Reverse relation for Detection objects (related_name="frame_count")
                            queryset=Detection.objects.filter(
                                crowd_density__gte=F('frame__camera__human_threshold')
                            ),
                            to_attr='filtered_detections'
                        )
                    )
                )
            )
        )

        print(f"Cameras for User {user.id}: {cameras.count()}")

        if not cameras.exists():
            print("No cameras found for this user.")
            return Response({'error': 'No cameras found for this user'}, status=status.HTTP_404_NOT_FOUND)

        results = []

        for camera in cameras:
            # Log camera details and its human_threshold
            print(f"Camera: {camera.id}, Threshold: {camera.human_threshold}")

            # Retrieve frames from camera via the 'frames' attribute
            frames = camera.frames.all()
            print(f"Frames for Camera {camera.id}: {frames.count()}")

            if not frames:
                print(f"No frames found for Camera {camera.id}.")
                continue

            for frame in frames:
                print(f"Frame: {frame.id}")

                # Retrieve pre-fetched, filtered predictions and detections
                predictions = getattr(frame, 'filtered_predictions', [])
                detections = getattr(frame, 'filtered_detections', [])
                print(f"Predictions: {len(predictions)}, Detections: {len(detections)}")

                if predictions or detections:
                    results.append({
                        'camera_id': camera.id,
                        'camera_threshold': camera.human_threshold,
                        'frame_id': frame.id,
                        'predictions': [
                            {'id': pred.id, 'crowd_density': pred.crowd_density, 'timestamp':pred.timestamp} 
                            for pred in predictions
                        ],
                        'detections': [
                            {'id': det.id, 'crowd_density': det.crowd_density, 'timestamp':det.timestamp} 
                            for det in detections
                        ],
                    })

        if not results:
            print("No results found.")
            return Response({'message': 'No data found'}, status=status.HTTP_200_OK)

        return Response(results, status=status.HTTP_200_OK)


# your_app/api/views.py



# from datetime import datetime, time, timedelta
# from django.utils.timezone import make_aware
# from django.db.models import F, Prefetch
# from rest_framework.views import APIView
# from rest_framework.permissions import IsAuthenticated
# from rest_framework.response import Response
# from rest_framework import status

# from camera_control.models import Camera
# from .models import Frame, Prediction, Detection

# class NotificationData(APIView):
#     permission_classes = [IsAuthenticated]

#     def get(self, request, *args, **kwargs):
#         user = request.user
#         if user.is_anonymous:
#             return Response(
#                 {'error': 'Authentication required'},
#                 status=status.HTTP_401_UNAUTHORIZED
#             )

#         # 1) Require & parse ?date=YYYY-MM-DD
#         date_str = request.query_params.get('date')
#         if not date_str:
#             return Response(
#                 {'error': 'Please provide ?date=YYYY-MM-DD'},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#         try:
#             requested_date = datetime.strptime(date_str, '%Y-%m-%d').date()
#         except ValueError:
#             return Response(
#                 {'error': 'Bad date format; use YYYY-MM-DD'},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         # 2) Build timezone-aware start/end for that day
#         start_dt = make_aware(datetime.combine(requested_date, time.min))
#         end_dt   = start_dt + timedelta(days=1)

#         # 3) Prepare a Frame queryset restricted to that exact 24‑hour window
#         frames_for_date = Frame.objects.filter(
#             timestamp__gte=start_dt,
#             timestamp__lt=end_dt
#         ).prefetch_related(
#             Prefetch(
#                 'frame_pred',
#                 queryset=Prediction.objects.filter(
#                     crowd_density__gte=F('frame__camera__human_threshold')
#                 ),
#                 to_attr='filtered_predictions'
#             ),
#             Prefetch(
#                 'frame_count',
#                 queryset=Detection.objects.filter(
#                     crowd_density__gte=F('frame__camera__human_threshold')
#                 ),
#                 to_attr='filtered_detections'
#             )
#         )

#         # 4) Fetch this user’s cameras, but only attach that day’s frames
#         cameras = Camera.objects.filter(location__user=user).prefetch_related(
#             Prefetch(
#                 'frames',
#                 queryset=frames_for_date,
#                 to_attr='filtered_frames'
#             )
#         )

#         # 5) Build the response list
#         results = []
#         for camera in cameras:
#             threshold = camera.human_threshold
#             for frame in getattr(camera, 'filtered_frames', []):
#                 preds = getattr(frame, 'filtered_predictions', [])
#                 dets  = getattr(frame, 'filtered_detections', [])
#                 if not preds and not dets:
#                     continue

#                 results.append({
#                     'camera_id':        camera.id,
#                     'camera_threshold': threshold,
#                     'frame_id':         frame.id,
#                     'predictions': [
#                         {
#                           'id':            p.id,
#                           'crowd_density': p.crowd_density,
#                           'timestamp':     p.timestamp.isoformat()
#                         } for p in preds
#                     ],
#                     'detections': [
#                         {
#                           'id':            d.id,
#                           'crowd_density': d.crowd_density,
#                           'timestamp':     d.timestamp.isoformat()
#                         } for d in dets
#                     ],
#                 })

#         # 6) Return empty array if no results
#         if not results:
#             return Response([], status=status.HTTP_200_OK)

#         return Response(results, status=status.HTTP_200_OK)
