from rest_framework import serializers

from camera_control.models import Camera
from .models import Frame, Prediction, Detection, Notification


class FrameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Frame
        fields = "__all__"


class PredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Prediction
        fields = ['crowd_density','timestamp','frame']
        
    # Now, the timestamp field will be formatted as YYYY-MM-DD HH:MM in the response.  
    def get_timestamp(self, obj):
        return obj.timestamp.strftime('%Y-%m-%d %H:%M')  # Custom format

class DetectionSerializer(serializers.ModelSerializer):
    class Meta:
        model= Detection
        fields = ['crowd_density','timestamp','frame']

    # Now, the timestamp field will be formatted as YYYY-MM-DD HH:MM in the response.   
    def get_timestamp(self, obj):
        return obj.timestamp.strftime('%Y-%m-%d %H:%M')  # Custom format

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'message', 'source', 'created_at']
