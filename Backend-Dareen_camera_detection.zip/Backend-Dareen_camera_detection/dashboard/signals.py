import os
import sys
import django
#sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
#os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'my_project.settings')
#django.setup()

from django.db.models.signals import post_save
from django.dispatch import receiver
from dashboard.models import Frame#, Detection, Prediction, Notification, Camera, 
from dashboard.detection import process_frame_detection_task

@receiver(post_save, sender=Frame) 
def trigger_detection(sender, instance, created, **kwargs):
    if created:
        process_frame_detection_task(instance.id)


