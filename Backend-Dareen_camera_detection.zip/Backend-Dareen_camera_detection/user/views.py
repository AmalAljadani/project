# from django.http import JsonResponse
# from django.shortcuts import render
# from django.contrib.auth import authenticate, login
from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
# from rest_framework_simplejwt.tokens import RefreshToken
# from .serializers import UserRegistrationSerializer, LoginSerializer, UserProfileSerializer, LocationSerializer
from rest_framework import generics

from .models import Location
# from rest_framework.decorators import api_view, permission_classes
# from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from rest_framework import generics
from rest_framework_simplejwt.views import TokenObtainPairView
from .serializers import LocationSerializer, UserSerializer, CustomTokenObtainPairSerializer



# Create your views here.
# User Registration View
class UserRegisterView(generics.CreateAPIView):
    serializer_class = UserSerializer

# Login View (JWT Token Generation)
class LoginView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer

# Register View
# class RegisterView(generics.CreateAPIView):
#     serializer_class = UserRegistrationSerializer

# # Login View
# class LoginView(APIView):
#     def post(self, request):
#         serializer = LoginSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)

#         user = serializer.validated_data['user']
#         refresh = RefreshToken.for_user(user)

#         return Response({
#             'refresh': str(refresh),
#             'access': str(refresh.access_token)
#         })
####################
# Get User Profile
# class UserProfileView(generics.RetrieveAPIView):
#     serializer_class = UserProfileSerializer
#     permission_classes = [IsAuthenticated]

#     def get_object(self):
#         return self.request.user

class LocationList(APIView):
    def get(self, request):
        # Get all locations
        locations = Location.objects.all()
        serializer = LocationSerializer(locations, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Create a new location
        serializer = LocationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LocationDetail(APIView):
    def get(self, request, pk):
        # Get a specific location by ID
        try:
            location = Location.objects.get(pk=pk)
        except Location.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        serializer = LocationSerializer(location)
        return Response(serializer.data)

    def put(self, request, pk):
        # Update an existing location
        try:
            location = Location.objects.get(pk=pk)
        except Location.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        serializer = LocationSerializer(location, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        # Delete a specific location
        try:
            location = Location.objects.get(pk=pk)
            location.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Location.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
# seetings
# API to get user profile info

# @api_view(['GET'])
# @permission_classes([IsAuthenticated])
# def user_settings(request):
#     user = request.user
#     serializer = UserSerializer(user)
#     return JsonResponse({'user': serializer.data})

# # API to get all locations for the logged-in user
# @api_view(['GET'])
# @permission_classes([IsAuthenticated])
# def user_locations(request):
#     locations = Location.objects.filter(user=request.user)
#     serializer = LocationSerializer(locations, many=True)
#     return JsonResponse({'locations': serializer.data})

# # API to add a new location
# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def add_location(request):
#     data = request.data
#     data['user'] = request.user.id  # Attach logged-in user to the location
#     serializer = LocationSerializer(data=data)
#     if serializer.is_valid():
#         serializer.save()
#         return JsonResponse({'message': 'Location added successfully!'}, status=201)
#     return JsonResponse(serializer.errors, status=400)

# # API to delete a location
# @api_view(['DELETE'])
# @permission_classes([IsAuthenticated])
# def delete_location(request, location_id):
#     location = Location.objects.filter(id=location_id, user=request.user).first()
#     if location:
#         location.delete()
#         return JsonResponse({'message': 'Location deleted successfully!'}, status=200)
#     return JsonResponse({'error': 'Location not found!'}, status=404)