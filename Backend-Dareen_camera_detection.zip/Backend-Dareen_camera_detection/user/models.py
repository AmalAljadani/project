from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Location (models.Model):
    ENTERTAINMENT = 'Entertainment'
    CULTURAL = 'Cultural'
    GENERAL = 'General'
    OTHER = 'Other'

    LOCATION_TYPES = [
        (ENTERTAINMENT, 'Entertainment'),
        (CULTURAL, 'Cultural'),
        (GENERAL, 'General'),
        (OTHER, 'Other'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='locations')
    
    location_name=models.CharField(max_length=255)
    location_type=models.CharField(max_length=50, choices=LOCATION_TYPES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    address = models.TextField()
    #coordinates = models.PointField(geography=True)

    def __str__(self):
        return self.location_name
