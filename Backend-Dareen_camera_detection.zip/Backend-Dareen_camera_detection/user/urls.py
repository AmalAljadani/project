from django.urls import path
# from .views import UserRegistrationView, UserLoginView
# from .views import user_settings, user_locations, add_location, delete_location
from .views import UserRegisterView, LoginView
from rest_framework_simplejwt.views import TokenRefreshView
from . import views
urlpatterns = [
    path('register/', UserRegisterView.as_view(), name='user-register'),
    path('login/', LoginView.as_view(), name='user-login'),
    #path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    #path('logout/', LoginView.as_view(), name='user-login'),

    
    path('locations/', views.LocationList.as_view(), name='location-list'),  # List and create locations
    path('locations/<int:pk>/', views.LocationDetail.as_view(), name='location-detail'),  # Retrieve, update, or delete a location

    # path('settings/', RegisterView.as_view(), name='user-settings'),
    # path('settings/locations/', user_locations, name='user-locations'),
    # path('settings/locations/add/', add_location, name='add-location'),
    # path('settings/locations/delete/<int:location_id>/', delete_location, name='delete-location'),
    #path('profile/', UserProfileView.as_view(), name='user-profile'),
]