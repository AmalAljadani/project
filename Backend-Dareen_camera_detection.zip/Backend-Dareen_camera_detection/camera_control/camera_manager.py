import cv2
from django.conf import settings
import threading
import time

class CameraManager:
    _instance = None
    _cameras = {}
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(CameraManager, cls).__new__(cls)
        return cls._instance

    def get_camera_stream(self, camera_id):
        with self._lock:
            if camera_id in self._cameras:
                return self._cameras[camera_id]
            return None

    def add_camera(self, camera):
        with self._lock:
            if camera.id in self._cameras:
                self.remove_camera(camera.id)
            
            try:
                cap = cv2.VideoCapture(camera.stream_url)
                if cap.isOpened():
                    self._cameras[camera.id] = {
                        'capture': cap,
                        'status': 'on',
                        'thread': None
                    }
                    return True
                return False
            except Exception as e:
                print(f"Error connecting to camera {camera.id}: {str(e)}")
                return False

    def remove_camera(self, camera_id):
        with self._lock:
            if camera_id in self._cameras:
                camera_data = self._cameras.pop(camera_id)
                try:
                    camera_data['capture'].release()
                except:
                    pass
                return True
            return False

    def start_streaming(self, camera_id, callback):
        def stream_thread():
            while True:
                with self._lock:
                    if camera_id not in self._cameras:
                        break
                    camera_data = self._cameras[camera_id]
                
                ret, frame = camera_data['capture'].read()
                if ret:
                    callback(frame)
                else:
                    time.sleep(0.1)

        with self._lock:
            if camera_id in self._cameras and self._cameras[camera_id]['thread'] is None:
                thread = threading.Thread(target=stream_thread)
                self._cameras[camera_id]['thread'] = thread
                thread.start()
                return True
            return False
        
    def get_frame(self, camera_id):
     with self._lock:
        if camera_id not in self._cameras:
            return None
        
        camera_data = self._cameras[camera_id]
        ret, frame = camera_data['capture'].read()
        if ret:
            return frame
        return None

def process_frame(self, camera_id, frame):
    # Add your frame processing logic here
    # For example, human detection
    return frame