from django.db import models
from user.models import Location
# Create your models here.
class Camera (models.Model):
    STATUS_CHOICES = [
        ('on', 'On'),
        ('off', 'Off'),
    ]

    
    id = models.AutoField(primary_key=True)
    status = models.CharField(max_length=3, choices=STATUS_CHOICES, default='on')
    human_threshold = models.IntegerField()  # Threshold for detecting humans

   

    # Generated stream URL (can be computed from the above fields)
    stream_url = models.CharField(max_length=255, blank=True, null=True)  # URL for accessing the camera's video stream
    
    location = models.ForeignKey(Location, related_name='cameras', on_delete=models.CASCADE)

    def __str__(self):
        return f"Camera {self.id} "
    
   