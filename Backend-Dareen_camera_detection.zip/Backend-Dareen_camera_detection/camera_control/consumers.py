# from channels.generic.websocket import AsyncWebsocketConsumer
# import json

# class UpdateConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.channel_layer.group_add("updates", self.channel_name)
#         await self.accept()

#     async def disconnect(self, close_code):
#         await self.channel_layer.group_discard("updates", self.channel_name)

#     async def send_update(self, event):
#         # Send updates to the frontend
#         await self.send(text_data=json.dumps(event))

# camera_control/consumers.py

from channels.generic.websocket import AsyncWebsocketConsumer
import json

class UpdateConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Add the client to the "updates" group
        await self.channel_layer.group_add("updates", self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        # Remove the client from the "updates" group
        await self.channel_layer.group_discard("updates", self.channel_name)

    async def send_update(self, event):
        # Send updates to the frontend
        await self.send(text_data=json.dumps(event))