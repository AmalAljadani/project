# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status

# from user.models import Location
# from .models import Camera
# from .serializers import CameraSerializer
# from rest_framework.permissions import IsAuthenticated


# class CameraList(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

#     def get(self, request):
#         """
#         Fetch cameras for the authenticated user.
#         """
#         # Fetch all cameras for the authenticated user's locations
#         cameras = Camera.objects.filter(
#             location__user=request.user
#         )  # Filters cameras by location's user
#         serializer = CameraSerializer(cameras, many=True)
#         return Response(serializer.data)
    
#     def post(self, request):
#          """
#           Add a new camera for the authenticated user.
#           """
#          data = request.data

#       # Automatically get the location for the user
#          try:
#              location = Location.objects.get(user=request.user)
#          except Location.DoesNotExist:
#              return Response(
#              {"error": "User does not have a valid location."},
#             status=status.HTTP_400_BAD_REQUEST,
#         )

#      # Add location to request data
#          data["location"] = location.id  

#          serializer = CameraSerializer(data=data)
#          if serializer.is_valid():
#                serializer.save()
#                return Response(serializer.data, status=status.HTTP_201_CREATED)
#          return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# class CameraDetail(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

#     def get(self, request, pk):
#         """
#         Fetch camera by its primary key for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         serializer = CameraSerializer(camera)
#         return Response(serializer.data)

#     def put(self, request, pk):
#         """
#         Update camera details for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         # Get the user's location automatically
#         try:
#             location = Location.objects.get(user=request.user)
#         except Location.DoesNotExist:
#             return Response(
#                 {"error": "User does not have a valid location."},
#                 status=status.HTTP_400_BAD_REQUEST,
#             )

#         # Add location to the request data before updating
#         request.data["location"] = location.id

#         serializer = CameraSerializer(camera, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
#     def delete(self, request, pk):
#         """
#         Delete camera for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         camera.delete()
#         return Response(status=status.HTTP_204_NO_CONTENT)
############################

#---- this is the code before i update it in RAMADAN 11
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from user.models import Location
# from .models import Camera
# from .serializers import CameraSerializer
# from rest_framework.permissions import IsAuthenticated
# ##----
# from channels.layers import get_channel_layer
# from asgiref.sync import async_to_sync
# import json

# class CameraList(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

#     def get(self, request):
#         """
#         Fetch cameras for the authenticated user.
#         """
#         # Fetch all cameras for the authenticated user's locations
#         cameras = Camera.objects.filter(
#             location__user=request.user
#         )  # Filters cameras by location's user
#         serializer = CameraSerializer(cameras, many=True)
#         return Response(serializer.data)

#     def post(self, request):
#         """
#         Add a new camera for the authenticated user.
#         """
#         data = request.data

#         # Automatically get the location for the user
#         try:
#             location = Location.objects.get(user=request.user)
#         except Location.DoesNotExist:
#             return Response(
#                 {"error": "User does not have a valid location."},
#                 status=status.HTTP_400_BAD_REQUEST,
#             )

#         # Add location to request data
#         data["location"] = location.id

#         serializer = CameraSerializer(data=data)
#         if serializer.is_valid():
#             serializer.save()

#             # Broadcast the new camera to all connected clients
#             channel_layer = get_channel_layer()
#             async_to_sync(channel_layer.group_send)(
#                 "updates",  # Group name
#                 {
#                     "type": "send_update",  # Method name in the consumer
#                     "message": "Camera added",
#                     "data": serializer.data,  # Send the serialized camera data
#                 },
#             )

#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
# class CameraDetail(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

#     def get(self, request, pk):
#         """
#         Fetch camera by its primary key for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         serializer = CameraSerializer(camera)
#         return Response(serializer.data)

#     def put(self, request, pk):
#         """
#         Update camera details for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         # Get the user's location automatically
#         try:
#             location = Location.objects.get(user=request.user)
#         except Location.DoesNotExist:
#             return Response(
#                 {"error": "User does not have a valid location."},
#                 status=status.HTTP_400_BAD_REQUEST,
#             )

#         # Add location to the request data before updating
#         request.data["location"] = location.id

#         serializer = CameraSerializer(camera, data=request.data)
#         if serializer.is_valid():
#             serializer.save()

#             # Broadcast the updated camera to all connected clients
#             channel_layer = get_channel_layer()
#             async_to_sync(channel_layer.group_send)(
#                 "updates",  # Group name
#                 {
#                     "type": "send_update",  # Method name in the consumer
#                     "message": "Camera updated",
#                     "data": serializer.data,  # Send the serialized camera data
#                 },
#             )

#             return Response(serializer.data)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     def delete(self, request, pk):
#         """
#         Delete camera for the authenticated user.
#         """
#         try:
#             camera = Camera.objects.get(
#                 pk=pk, location__user=request.user
#             )  # Ensure camera belongs to the user
#         except Camera.DoesNotExist:
#             return Response(
#                 {"error": "Camera not found or does not belong to you."},
#                 status=status.HTTP_404_NOT_FOUND,
#             )

#         # Broadcast the deleted camera to all connected clients
#         channel_layer = get_channel_layer()
#         async_to_sync(channel_layer.group_send)(
#             "updates",  # Group name
#             {
#                 "type": "send_update",  # Method name in the consumer
#                 "message": "Camera deleted",
#                 "data": {"id": camera.id},  # Send the ID of the deleted camera
#             },
#         )

#         camera.delete()
#         return Response(status=status.HTTP_204_NO_CONTENT)




#-- THIS IS THE UPDATED CODE IN RAMADAN 11----

# camera_control/views.py

import cv2
from django.http import StreamingHttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from user.models import Location
from .models import Camera
from .serializers import CameraSerializer
from rest_framework.permissions import IsAuthenticated
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import json

from .camera_utils import validate_rtsp_stream

class CameraList(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """
        Fetch cameras for the authenticated user.
        """
        cameras = Camera.objects.filter(location__user=request.user)
        serializer = CameraSerializer(cameras, many=True)
        return Response(serializer.data)

    def post(self, request):
        """
        Add a new camera for the authenticated user.
        This endpoint now checks the RTSP stream before adding the camera.
        """
        data = request.data

        # Ensure the stream_url is provided in the data.
        rtsp_url = data.get("stream_url")
        if not rtsp_url:
            return Response(
                {"error": "Stream URL is required."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate the RTSP stream before saving the camera.
        if not validate_rtsp_stream(rtsp_url):
            return Response(
                {"error": "Cannot connect to the provided RTSP stream."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Automatically get the location for the user.
        try:
            location = Location.objects.get(user=request.user)
        except Location.DoesNotExist:
            return Response(
                {"error": "User does not have a valid location."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Add location to request data.
        data["location"] = location.id
        serializer = CameraSerializer(data=data)
        if serializer.is_valid():
            serializer.save()

            # Broadcast new camera to connected clients.
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "updates",
                {
                    "type": "send_update",
                    "message": "Camera added",
                    "data": serializer.data,
                }
            )

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#--------------------------THIS THE ORIGINAL CODE WHERE CAMERA NORAMLLY ADDED WITHOUT CHECKING IF THE STREAM IS VALID---------------
# class CameraList(APIView):
#     permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

#     def get(self, request):
#         """
#         Fetch cameras for the authenticated user.
#         """
#         # Fetch all cameras for the authenticated user's locations
#         cameras = Camera.objects.filter(location__user=request.user)
#         serializer = CameraSerializer(cameras, many=True)
#         return Response(serializer.data)


# # OLD CREATE NEW CAMERA ((without connection camera version)) !!!!
#     def post(self, request):
#         """
#         Add a new camera for the authenticated user.
#         """
#         data = request.data

#         # Automatically get the location for the user
#         try:
#             location = Location.objects.get(user=request.user)
#         except Location.DoesNotExist:
#             return Response(
#                 {"error": "User does not have a valid location."},
#                 status=status.HTTP_400_BAD_REQUEST,
#             )

#         # Add location to request data
#         data["location"] = location.id

#         serializer = CameraSerializer(data=data)
#         if serializer.is_valid():
#             serializer.save()

#             # Broadcast the new camera to all connected clients
#             channel_layer = get_channel_layer()
#             async_to_sync(channel_layer.group_send)(
#                 "updates",  # Group name
#                 {
#                     "type": "send_update",  # Method name in the consumer
#                     "message": "Camera added",
#                     "data": serializer.data,  # Send the serialized camera data
#                 },
#             )

#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#---------------------------------------------
class CameraDetail(APIView):
    permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

    def get(self, request, pk):
        """
        Fetch camera by its primary key for the authenticated user.
        """
        try:
            camera = Camera.objects.get(pk=pk, location__user=request.user)
        except Camera.DoesNotExist:
            return Response(
                {"error": "Camera not found or does not belong to you."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = CameraSerializer(camera)
        return Response(serializer.data)

    def put(self, request, pk):
        """
        Update camera details for the authenticated user.
        """
        try:
            camera = Camera.objects.get(pk=pk, location__user=request.user)
        except Camera.DoesNotExist:
            return Response(
                {"error": "Camera not found or does not belong to you."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Get the user's location automatically
        try:
            location = Location.objects.get(user=request.user)
        except Location.DoesNotExist:
            return Response(
                {"error": "User does not have a valid location."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Add location to the request data before updating
        request.data["location"] = location.id

        serializer = CameraSerializer(camera, data=request.data)
        if serializer.is_valid():
            serializer.save()

            # Broadcast the updated camera to all connected clients
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "updates",  # Group name
                {
                    "type": "send_update",  # Method name in the consumer
                    "message": "Camera updated",
                    "data": serializer.data,  # Send the serialized camera data
                },
            )

            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """
        Delete camera for the authenticated user.
        """
        try:
            camera = Camera.objects.get(pk=pk, location__user=request.user)
        except Camera.DoesNotExist:
            return Response(
                {"error": "Camera not found or does not belong to you."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Broadcast the deleted camera to all connected clients
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "updates",  # Group name
            {
                "type": "send_update",  # Method name in the consumer
                "message": "Camera deleted",
                "data": {"id": camera.id},  # Send the ID of the deleted camera
            },
        )

        camera.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    