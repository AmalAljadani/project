import cv2

# RTSP URL with credentials
RTSP_URL = "rtsp://admin:L258DE63@192.168.8.177:554/cam/realmonitor?channel=1&subtype=0"

# Open the RTSP stream
cap = cv2.VideoCapture(RTSP_URL)

if not cap.isOpened():
    print("❌ Error: Cannot connect to camera stream")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Error: Couldn't read frame. Retrying...")
        continue

    # Display the live video feed
    cv2.imshow("RTSP Stream", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()

