# camera_utils.py
import cv2
import time
from io import BytesIO
from PIL import Image
from django.core.files.base import ContentFile
from django.utils import timezone
from .models import Camera
from dashboard.models import Frame

def validate_rtsp_stream(rtsp_url, timeout=10):
    """
    Tries to connect to the RTSP stream and read a frame within `timeout` seconds.
    Returns True if a frame is successfully read, otherwise False.
    """
    cap = cv2.VideoCapture(rtsp_url)
    start_time = time.time()

    # Check if the stream opens; allow a brief retry
    if not cap.isOpened():
        time.sleep(0.5)
        if not cap.isOpened():
            cap.release()
            return False

    while time.time() - start_time < timeout:
        ret, frame = cap.read()
        if ret:
            cap.release()
            return True

    cap.release()
    return False


def capture_frame_from_camera(camera):
    """
    Opens the RTSP stream from the given camera, reads one frame,
    and returns the image bytes in JPEG format.
    """
    rtsp_url = camera.stream_url
    cap = cv2.VideoCapture(rtsp_url)
    
    # Check if the camera opened correctly
    if not cap.isOpened():
        print(f"❌ Error: Cannot connect to the RTSP stream for Camera {camera.id}")
        return None
    
    ret, frame = cap.read()
    cap.release()
    
    if not ret:
        print(f"❌ Error: Couldn't capture a frame from Camera {camera.id}")
        return None

    # Convert frame from BGR to RGB, then to a PIL image.
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(frame_rgb)
    
    # Save the image to an in-memory buffer in JPEG format.
    buffer = BytesIO()
    pil_image.save(buffer, format='JPEG')
    image_bytes = buffer.getvalue()
    buffer.close()
    return image_bytes

# def save_frame(camera, image_bytes):
#     """
#     Save the image bytes as a Frame associated with the given camera.
#     """
#     if image_bytes is None:
#         return
    
#     # Create a new Frame instance (timestamp is added automatically)
#     frame_instance = Frame.objects.create(
#         camera=camera,
#         timestamp=timezone.now()
#     )
#     # Generate a unique name using a timestamp
#     image_name = f"camera_{camera.id}_frame_{int(time.time())}.jpg"
    
#     # Save the image file to the 'frame' field
#     frame_instance.frame.save(image_name, ContentFile(image_bytes))
#     frame_instance.save()
#     print(f"✅ Saved frame for Camera {camera.id}")

def save_frame(camera, image_bytes):
    if not image_bytes:
        return

    image_name = f"camera_{camera.id}_frame_{int(time.time())}.jpg"
    # Create & save in one go:
    frame_instance = Frame.objects.create(
        camera=camera,
        timestamp=timezone.now(),
        frame=ContentFile(image_bytes, image_name)
    )
    print(f"✅ Saved frame for Camera {camera.id} (with file)")
    return frame_instance
