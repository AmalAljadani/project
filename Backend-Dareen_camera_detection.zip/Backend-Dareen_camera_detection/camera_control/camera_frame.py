import cv2
import os
import datetime
import time


videoPath = r"rtsp://admin:L258DE63@192.168.8.177:554/cam/realmonitor?channel=1&subtype=0"
capture = cv2.VideoCapture(videoPath)
newpath = r"/Users/darenhamed/Amneen Desktop application/Backend/media"

if not os.path.exists(newpath):
    os.makedirs(newpath)

count = 1 #counter


while(True):
    ret, frame = capture.read()

    if not ret:
        break

    # method 4
    filename = f"{newpath}\\frame_{count:04d}.jpg"
    print("printed")
    current_time = datetime.datetime.now().time()
    print("Current time:", current_time)
    cv2.imwrite(filename, frame)
    time.sleep(300)
    count += 1

capture.release()
cv2.destroyAllWindows()

