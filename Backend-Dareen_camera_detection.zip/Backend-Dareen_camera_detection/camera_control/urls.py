# camera_control/urls.py
from django.urls import path
from .views import CameraList, CameraDetail

urlpatterns = [
    path('camera/', CameraList.as_view(), name='camera-list-add'), 
    path('camera/<int:pk>/', CameraDetail.as_view(), name='camera-detail'),
]
