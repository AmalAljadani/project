from celery import shared_task
from .models import Camera
from .camera_utils import capture_frame_from_camera, save_frame

@shared_task
def capture_frames_from_all_cameras():
    """
    This task retrieves all cameras with status 'on' and attempts to capture one frame
    from each camera's RTSP stream, then saves the frame.
    """
    cameras = Camera.objects.filter(status='on')
    for camera in cameras:
        image_bytes = capture_frame_from_camera(camera)
        if image_bytes:
            save_frame(camera, image_bytes)
